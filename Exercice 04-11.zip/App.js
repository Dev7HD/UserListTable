const pageSize = 10
const tbody = document.querySelector('tbody')

// La fonction 'dataTable' retourn les données suivant la page actuelle // 
function dataTable(currentPage){
    const a = currentPage * pageSize -10;
    const b = currentPage * pageSize ;
    return users.slice(a, b).map(user => ({
        fName: user.firstName,
        lName: user.lastName,
        bDay: user.birthDate
    }));
}

// La fonction creatRow sert à creé les lignes de la table  //
function creatRow(fName,lName,bDay){
    const tr = document.createElement('tr')
    tr.classList.add('row_data');
    const td1 = document.createElement('td')
    const td2 = document.createElement('td')
    const td3 = document.createElement('td')
    td1.innerText = fName
    td2.innerText = lName
    td3.innerText = bDay
    tr.append(td1, td2, td3)
    return tr
}

// La fonction addRowData sert à remplire les lignes de la table //
function dataRow(currentPage){
    addRowData(currentPage)
    pageNonColor()
    pageColor(currentPage)
}
function addRowData(currentPage){
    tbody.innerHTML = '';
    const mappedUsers = dataTable(currentPage);
    mappedUsers.forEach(user => {
        tbody.appendChild(creatRow(user.fName,user.lName,user.bDay))
    })
    
}
function pageColor(currentPage){
    const element = document.getElementById(currentPage)
    element.style.color = "cadetblue"
}
function pageNonColor(){
    const elements = document.querySelectorAll('span')
    elements.forEach(element => {
        element.style.color = 'white'
    })
}
dataRow(1);

let order = true;

// La variable 'rows' contienne les données saisies dans chaque ligne de la table //
let rows = Array.from(tbody.querySelectorAll('tr'))

// La fonction 'sortTable' trie la table suivant la colonne clickée //
function sortTable(columnIndex, dataType) {
    tbody.innerHTML = '';
    order = !order;
    rows.sort((a, b) => {
        const aValue = a.cells[columnIndex].textContent.toString().toUpperCase().trim();
        const bValue = b.cells[columnIndex].textContent.toString().toUpperCase().trim();

        if (dataType === 'string') {
            return aValue.localeCompare(bValue);
        } else if (dataType === 'date') {
            return new Date(aValue) - new Date(bValue);
        }
    })

    if(!order){
        tbody.innerHTML = '';
        rows.reverse();
    }
    rows.forEach((row) => tbody.appendChild(row));
}